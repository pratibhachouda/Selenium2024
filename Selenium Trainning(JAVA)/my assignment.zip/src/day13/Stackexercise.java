package day13;

import java.util.Stack;

public class Stackexercise {

	public static void main(String[] args) {
		
		Stack<String> stack = new Stack<String>();
		 
		   stack.push("walmart");
		   stack.push("target");
		   stack.push("costco");
		   stack.push("macys");
		   stack.push("tj maxx");
		   
		  
		  // String myfavstore =stack.pop();
		  
		   System.out.println(stack.peek());
		   
		   System.out.println(stack);
		   System.out.println(stack.search("walmart"));
		   
	}

}
