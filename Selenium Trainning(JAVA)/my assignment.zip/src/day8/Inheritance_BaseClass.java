package day8;



public class Inheritance_BaseClass {
	
	
	
	int z;
	public void add (int x,int y) {
		z=x+y;
		System.out.println("Addition:"+z);
	}

	public void sub (int x,int y) {
		
		
	z=x-y;
	System.out.println("Subtraction;"+z);
	}
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
