package day8;

public class ClassA {
   int i =10;
	public static void main(String[] args) {
		

	}

}
