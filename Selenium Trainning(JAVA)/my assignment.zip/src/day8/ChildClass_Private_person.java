package day8;

public class ChildClass_Private_person extends Private_Person{

	
	
	public static void main(String[] args) {
		ChildClass_Private_person obj = new ChildClass_Private_person();
	
		System.out.println(getName());

	}

}
 