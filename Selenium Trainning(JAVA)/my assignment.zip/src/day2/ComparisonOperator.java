package day2;

public class ComparisonOperator {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		// =  = is equal to
		// <= = less than equal to
		// >= = grater than equal to
		// <  = less than 
		// >  = grater than 
		int a = 4;
		int b = 5;
		
		boolean c = (a!=b); {
		  System.out.println("c");
		}
		  double x = 14.9;
		  double y = 14.9; 
		  
		  boolean z = (x!=y); { 
		  System.out.println(" equal");   
		  
		  if (a==4) {
			  System.out.println("Its a match");
		  }
		  
		  if (b>4) {
			  System.out.println("Its not true");
			    }
		if (x==14) {
			System.out.println("Its a match");
		}
		  
		else {
			System.out.println("Not Matching");
			
		}
		  
		  }
		  
		  
		  
	}

}
