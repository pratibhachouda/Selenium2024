package day2;

public class SwitchStatement {

	public static void main(String[] args) 
		// TODO Auto-generated method stub
        //switch-evaluate once
		//if there is match it execute associate block of code
		//it also has break and default
		{
		int	dayofweek =5;
	
	    switch (dayofweek) {
	
	    case 1:
	           System.out.println("Monday");
	     break;
	
	    case 2:
	        System.out.println("Tuesday");
		     break;
		     
	    case 3:
	        System.out.println("Wednesday");
		     break;    
		     
	    case 4:
	        System.out.println("Thursday");
		     break;
	    case 5:
	        System.out.println("Friday");
		     break;
	    case 6:
	        System.out.println("Saturday");
		     break;
	    case 7:
	        System.out.println("sunday");
		     break;
		     
		     
		     
	}
		
			}

}
