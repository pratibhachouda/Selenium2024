package day2;

public class LogicalOperators {

	public static void main(String[] args) {
		// Logical Operators
		
		int x = 90;
		int y = 9;
		
		System.out.println(x + y);
		System.out.println(x - y);
		System.out.println(x * y);
		System.out.println(x / y);
		System.out.println(y  % x);
		
		
		System.out.println(!(x>y && x >=90));
		
		// x>y == 90>8 which is true
		// also x >= 90 which is also true
		//both statement are true
		// but when use logical not it reverse the result 7 will return false
		
		System.out.println("mona");
		
		
	float A = 13;
	float b = 5	;
	System.out.println( A/b );
	
	

	}

}
