package day3;

public class ArraysExercise {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		String[]  Family ={"Saurabh","Pratibha","Advik","Ahaan"};
		
		
		System.out.println(Family.length);
		System.out.println( Family [3] );

	}

}
