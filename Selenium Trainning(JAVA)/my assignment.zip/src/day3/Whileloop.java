package day3;

public class Whileloop {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
         int i =0;
         //want to loop until my i becomes 5
         //using increment operator i can increase 1 value:  i++
         while(i<10) 
         {
        	 System.out.println( i);
        	i++; 
        	 
		
         }
	}
	
	
	
	
	

}
