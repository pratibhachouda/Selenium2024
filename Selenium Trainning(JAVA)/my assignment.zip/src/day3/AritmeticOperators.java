package day3;

public class AritmeticOperators {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		// increment
		// decrement
		
		int x = 20;
		int y = 40;
		System.out.println(--y);
		System.out.println(++y);
	
		
		
		System.out.println(++x);
		
		System.out.println(--x);
		System.out.println(--x);

	}

}
