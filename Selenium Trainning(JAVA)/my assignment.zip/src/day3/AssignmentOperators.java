package day3;

public class AssignmentOperators {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
        
		//=,  x=5
		//+=, x+=5   =  x=x+5
		//-=, x-=5 same as x= x-=5
		
		  int x = 0;
		
		System.out.println( x+=5); //its equal to x=x+5
		System.out.println(x-=6);   //its same as x=x-6
		
		
		
	}
	
	
	
	
	
	

}
