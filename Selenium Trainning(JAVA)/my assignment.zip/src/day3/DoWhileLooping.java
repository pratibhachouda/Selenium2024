package day3;

public class DoWhileLooping {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int i = 6;
		
		do {
			System.out.println(i);
			i--;
		}
		while(i>2);	
			
		}
		
		
		
		
		
	}


