package day11;

public class FinalKeyword {

	public static void main(String[] args) {
	final	int num =10;
		System.out.println(num);		
	}

}
