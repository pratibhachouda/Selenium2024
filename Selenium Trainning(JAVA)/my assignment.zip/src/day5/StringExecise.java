package day5;

public class StringExecise {

	public static void main(String[] args) {
		
		
	String str ="PRATIBHA";	
	String str2 ="Tester";	
	
	
	System.out.println(str.concat(str2));
	
	//string length
	//string concat
	//string Lowercase
	//string uppercase
	
	
	if(str2.contains("e")) {
		System.out.println("straing has E");
		}
	else {
		System.out.println("straing doesn't contain E");
	}
	
	      String sentence ="I Am Awesome";
	      
	     //Reverse each word in String or Sentence
	      // i ma emosewA
	      System.out.println(sentence.length());
	      String[] splited =sentence.split(" ");
	      System.out.println(splited.length);
	      
	    
			System.out.println(str.indexOf('P'));
	
	
	
	}
	}
	

	


