package day9;

public class MainMethodOverriding {
//Method 1
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Pratibha");
	}
		
		//Method 2
		public static void main(String args) {
			System.out.println("Pratibha");
	
		}
			//Method 3
			public static void main  () {
				System.out.println("Pratibha");	
			}
	

}
