package day4;

public class cityname  {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String[]  familyname ={"Saurabh","Pratibha","Advik","Ahaan"};
		
		for(String family:familyname)  {
			System.out.println(family);
			
			if (family.equals("Pratibha")) {
				System.out.println("cityname is Georgia");
			}
			
		if(family.equals("Ahaan")) {
			System.out.println("cityname is Cumming");
		
		}
		if(family.equals("Advik")) {
			System.out.println("cityname is Alaska");
			}
		}
		
	}
	}

