package day4;

public class ArrayExercise2 {

	public static void main(String[] args) {
		
		
		String[] Fruits = {"Banana","Apple","Kiwi","Berries","Mango"};
		
		System.out.println( Fruits.length );
		
		// for loop to iterate the array
		
		for(int i=0; i<5;i++){
			System.out.println(Fruits[i]);
		}
	}

}
