package day4;

public class EvenoddEnhanced {

	public static void main(String[] args) {
		
		
            int a[]= {1,2,3,4,5,6};
		
		//extracting even no....
            
		System.out.println("Even no");
		
	          for(int value:a)
	          {
			
			if(value%2==0)
			System.out.println(value);
	}
	        //extracting Odd no....
	            
	  		System.out.println("Odd no");
	  		
	  	          for(int value:a)
	  	          {
	  			
	  			if(value%2!=0)
	  			System.out.println(value);
	  	}	}
}
