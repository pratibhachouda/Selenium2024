package day1;

public class Variable_day1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		
//public-access Modifiers ,type-public,private,protected,
//static- creates single memory in java
//main-method main
//string[] args ->input argument
		
		//System.out.print("Welcome to Training session Day1");
		
		//Creat a Variable-1.provide datatype and Variable name
		//Interger
		int age =30;
		String name="Pratibha";
		char inital ='p';
		//double,float,long
		double doublevalue= 69.397;
		float b=5.89f;		
		long longvalue=888888888;
		boolean StayingInIndia =true;
		System.out.println("My Name:"+name);    
		System.out.println("my intial:"+inital);
		System.out.println("My Age:"+age);
		System.out.println("Indian:"+StayingInIndia); 	
		System.out.println(b);
		System.out.println(doublevalue); 	
		System.out.println(longvalue); 
		System.out.println("Ahaan"); 
		
		
		
		
		
		
		
	  } 
	
	
	}
