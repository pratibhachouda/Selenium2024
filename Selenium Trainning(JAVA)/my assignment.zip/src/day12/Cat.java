package day12;

public class Cat implements AnimalType{

	//animal sound is coming from animal interface
	public void animalsound() {
		System.out.println("cat says meow meow");
		
	}
// AnimalType is coming from AnimalType interface
	
	public void animaltype() {
		// TODO Auto-generated method stub
		
	}

}
