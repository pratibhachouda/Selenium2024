package day12;

public class Dog implements AnimalType{
	
	public void animalsound () {
		System.out.println("Dog Bark");
	}

	
	public void animaltype() {
		// TODO Auto-generated method stub
		
	}

}
