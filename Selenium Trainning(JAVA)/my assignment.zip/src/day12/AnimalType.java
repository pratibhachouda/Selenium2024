package day12;

public interface AnimalType extends Animal {
	
	
	public void animaltype();
	

}
