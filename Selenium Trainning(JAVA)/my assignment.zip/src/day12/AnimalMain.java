package day12;

public class AnimalMain {

	public static void main(String[] args) {
		//Creating connection through Object//
		Dog dogobj=new Dog();
       dogobj.animalsound();
       Cat catobj=new Cat();
       catobj.animalsound();
	}

}
