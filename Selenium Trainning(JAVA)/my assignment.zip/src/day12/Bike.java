package day12;

public abstract class Bike {

	
	//Create abstract method	
	
	public abstract void run ();//abstract will not have any implementation
	

}
