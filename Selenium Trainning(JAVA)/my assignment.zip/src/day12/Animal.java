package day12;

interface Animal {
     public void animalsound();
     

}
